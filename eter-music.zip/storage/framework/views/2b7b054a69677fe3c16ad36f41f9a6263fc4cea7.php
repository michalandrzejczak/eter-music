<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h3>Moje wypożyczenia</h3>
        </div>
    </div>
<?php if(isset($instruments, $rents)): ?>
    <div class="row">
        <div class="col-12 col-md-8 col-lg-6 mx-auto">
            <table class="instrument-list display table-hover table"> 
                <thead>
                    <tr>
                        <th>Instrument</th>
                        <th>Od</th>
                        <th>Do</th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($instruments->find($rent->instrument_id)->title); ?>  
                        </td>
                        <td>
                            <?php echo e($rent->start); ?> 
                        </td>
                        <td>
                            <?php echo e($rent->end); ?> 
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>