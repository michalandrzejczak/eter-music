<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(Auth::user()->name); ?> - witaj w eter-music, internetowej wypożyczalni instrumentów jazzowych.
                </div>
            </div>
        </div>
    </div>
    <?php if(isset($instruments)): ?>
    <div class="row">
        <div class="instruments-thumbs">
            <?php $__currentLoopData = $instruments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instrument): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-8 col-lg-6 mx-auto">
                <div class="instrument-thumb">
                    <img src="img/instruments/<?php echo e($instrument->image); ?>" alt="instrument-photo" class="img-responsive" width="150">
                    <div class="caption">
                        <h4><?php echo e($instrument->title); ?></h4>
                        <p><?php echo e($instrument->description); ?></p>
                        <div class="btn-toolbar text-center">
                            <a href="/rents/<?php echo e($instrument->id); ?>" role="button" class="btn btn-secondary mx-auto">Wypożycz</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div> 
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>