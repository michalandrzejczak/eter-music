<?php $__env->startSection('content'); ?>
<div>
	<h3>Users here!</h3>
	<hr>
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, voluptas? Sint nam nobis cupiditate ab enim beatae, blanditiis vel deserunt, doloribus placeat eos reprehenderit atque voluptate! Officiis quaerat velit similique molestias reiciendis repudiandae sint consequuntur, excepturi perspiciatis, aperiam alias atque vitae molestiae adipisci earum ducimus a eaque, mollitia possimus debitis!</p>
</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>